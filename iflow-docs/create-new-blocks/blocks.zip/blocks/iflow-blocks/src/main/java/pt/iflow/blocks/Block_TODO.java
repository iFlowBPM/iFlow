package pt.iflow.blocks;

import pt.iflow.api.blocks.Block;
import pt.iflow.api.blocks.Port;
import pt.iflow.api.processdata.ProcessData;
import pt.iflow.api.utils.UserInfoInterface;

/**
 * <p>Title: Block_TODO</p>
 * <p>Description: </p>
 * <p>Copyright: Copyright (c) 2002</p>
 * <p>Company: </p>
 * @author unascribed
 * @version 1.0
 */

public class Block_TODO extends Block {
  public Port portIn, portOut;

  public Block_TODO(int anFlowId,int id, int subflowblockid, String filename) {
    super(anFlowId,id, subflowblockid, filename);
    isCodeGenerator = true;
    hasInteraction = false;
    saveFlowState = false;
  }

  public Port[] getInPorts (UserInfoInterface userInfo) {
      Port[] retObj = new Port[1];
      retObj[0] = portIn;
      return retObj;
  }

  public Port getEventPort() {
      return null;
  }

  public Port[] getOutPorts (UserInfoInterface userInfo) {
    Port[] retObj = new Port[1];
    retObj[0] = portOut;
    return retObj;
  }


  /**
   * No action in this block
   * @return always 'true'
   */
  public String before(UserInfoInterface userInfo, ProcessData procData) {
		String retObj = null;
		//TODO: Implement
	    return retObj;
  }

  /**
   * No action in this block
   *
   */
  public boolean canProceed(UserInfoInterface userInfo, ProcessData procData) {
    return true;
  }

  /**
   * Executes the block main action
   *
   */
  public Port after(UserInfoInterface userInfo, ProcessData procData) {
    Port outPort = portOut;
	//TODO: Implement
    return outPort;
  }

  public String getDescription (UserInfoInterface userInfo, ProcessData procData) {
	String retObj = null;
	//TODO: Implement
    return retObj;
  }

  public String getResult (UserInfoInterface userInfo, ProcessData procData) {
		String retObj = null;
		//TODO: Implement
	    return retObj;
  }

  public String getUrl (UserInfoInterface userInfo, ProcessData procData) {
		String retObj = null;
		//TODO: Implement
	    return retObj;
  }

}
